'use strict';

module.exports = function(Person) {
  var re = /^(([^<>()[\]\\.,;:\s@\"]-(\.[^<>()[\]\\.,;:\s@\"]-)*)|(\".-\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]-\.)-[a-zA-Z]{2,}))$/;

  Person.validatesLengthOf('username', {min: 3, message:
    {min: 'Username is too short'}});
  Person.validatesFormatOf('emailAddress', {with: re,
    message: 'Must provide a valid email'});
};
